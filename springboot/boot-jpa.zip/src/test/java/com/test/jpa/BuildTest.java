package com.test.jpa;

public class BuildTest {

}
